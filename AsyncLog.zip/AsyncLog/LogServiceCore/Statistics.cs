﻿using System;
using System.Diagnostics;
using LogEngine;

namespace LogServiceCore
{
    public class ServiceStatistics
    {
        public ServiceStatistics()
        {
            UptimeHours = 0;
            UptimeMinutes = 0;
            UptimeSeconds = 0;
            ErrorCount = 0;
            WarningCount = 0;
            InfoCount = 0;
            DebugCount = 0;
        }

        public int UptimeHours { get; set; }
        public int UptimeMinutes { get; set; }
        public int UptimeSeconds { get; set; }
        public uint ErrorCount { get; set; }
        public uint WarningCount { get; set; }
        public uint InfoCount { get; set; }
        public uint DebugCount { get; set; }
    }

    public sealed class Statistics
	{
        private static readonly object instLock = new object();
		private static Statistics? instance = null;

        private readonly Stopwatch sw = new();
		public uint ErrorCount { get; private set; }
        public uint WarningCount { get; private set; }
        public uint InfoCount { get; private set; }
        public uint TraceCount { get; private set; }

        public static Statistics Instance
        {
            get
            {
                lock (instLock)
                {
                    if (instance == null)
                    {
                        instance = new Statistics();
                    }

                    return instance;
                }
            }
        }

        private Statistics()
		{
			ErrorCount = 0;
			WarningCount = 0;
			InfoCount = 0;
			TraceCount = 0;

            sw.Start();
		}

		public ServiceStatistics Get()
		{
			ServiceStatistics stats = new();

			stats.UptimeHours = sw.Elapsed.Hours;
            stats.UptimeMinutes = sw.Elapsed.Minutes;
            stats.UptimeSeconds = sw.Elapsed.Seconds;
			stats.ErrorCount = ErrorCount;
            stats.WarningCount = WarningCount;
            stats.InfoCount = InfoCount;
            stats.DebugCount = TraceCount;

            return stats;
        }

        /// <summary>
        /// Returns the elapsed time since this service is running
        ///     Console.WriteLine("Time: {0}h {1}m {2}s {3}ms",
        ///		Uptime.Hours, Uptime.Minutes,
		///		Uptime.Seconds, Uptime.Milliseconds);
		/// </summary>
		public TimeSpan Uptime
		{
			get { return (sw.Elapsed); }
        }

		public void CountEventsOfType(LogEngine.Level level)
		{
			switch(level)
			{
				case Level.Error:
					ErrorCount++;
					break;

				case Level.Warning:
					WarningCount++;
					break;

				case Level.Info:
					InfoCount++;
					break;

				case Level.Trace:
					TraceCount++;
					break;

				default:
					throw new Exception(string.Format("Unknown log level: {0}", level));
			}
		}
    }
}

