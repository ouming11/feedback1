﻿using System;

namespace LogServiceCore.Models
{
	public class LovEvent
	{
		public enum LogLevel
		{
			NotInitialized,
			Error,
			Warning,
			Info,
			Debug
		}

		public LovEvent()
		{
			Timestamp = DateTime.MinValue;
			Level = LogLevel.NotInitialized;
			Message = string.Empty;
        }

		public DateTime Timestamp { get; set; }
		public LogLevel Level { get; set; }
		public string Message { get; set; }

		public List<KeyValuePair<string, string>> Metadata = new();
	}
}

