﻿using System;
namespace LogServiceCore
{
	public static class Constant
	{
        public const string Trace = "Trace";
        public const string Info = "Info";
        public const string Warning = "Warning";
        public const string Error = "Error";
        public static string TimeStamp = "time";
        public static string Level = "level";
        public static string Message = "message";
        public static string Source = "source";
        public const string DateFormat = "yyyy-MM-ddTHH:mm:ss.fff";
    }
}
