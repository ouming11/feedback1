using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Reflection.Emit;
using System.Threading.Tasks;
using System.Text.Json;
using System.Text.Json.Serialization;
using LogEngine;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;

namespace LogServiceCore
{
    [Route("api/[controller]")]
    [ApiController]
    public class LogServiceController : ControllerBase
    {
        private static readonly string[] ReservedKeywords = {
            Constant.Error,
            Constant.Warning,
            Constant.Info,
            Constant.Trace,
            Constant.TimeStamp,
            Constant.Message,
            Constant.Level,
            Constant.Source
        };

        [HttpPost("echo")]
        [Consumes("application/json")]
        public string echo([FromBody] string body)
        {
            Console.WriteLine("Received: " + body);
            return body;
        }

        /// <summary>
        /// POST: api/LogService
        /// This endpoint accepts a log entry that should be logged somewhere
        /// Information to be logged is expected a stringified JSON object
        /// that contains as a minimum the following fields:
        /// "time": "yyyy-MM-ddTHH:mm:ss.fff"
        /// "level": "Info|Error|Warning|Debug"
        /// "source": "MyApp"
        /// "message": "Hello World"
        ///
        /// There can be optional number of key/value pairs for metadata
        /// Example:
        /// "{\"time\": \"2023-02-08T17:30:00.123\", \"level\": \"source\": \"MyApp\",
        ///   \"Info\", \"message\": \"Hello Mom!\", \"fruit\": \"Banana\",
        ///   \"pet\": \"Labrador\"}"
        /// </summary>
        /// <param name="logJsonTextString"></param>

        [HttpPost]
        public IActionResult Post([FromBody] string logJsonTextString)
        {
            try
            {
                Console.WriteLine(logJsonTextString);
                KeyValuePair<HttpStatusCode, dynamic> kvp = ValidateReceivedLogData(logJsonTextString);

                if (kvp.Key == HttpStatusCode.OK)
                {
                    // Should contain all the key value pairs needed for a lot entry.
                    Dictionary<string, dynamic> logDic = kvp.Value;

                    // If metadata was received, parse it
                    MetaData meta = BuildMetadata(logDic);

                    // We parse the received timestamp that is requested
                    // to be in Constant.DateFormat
                    DateTime evTimeStamp = DateTime.ParseExact(
                        logDic[Constant.TimeStamp].GetString(),
                        Constant.DateFormat,
                        System.Globalization.CultureInfo.InvariantCulture
                        );

                    Level logLevel = StringToLogLevel(logDic[Constant.Level].GetString());

                    Statistics.Instance.CountEventsOfType(logLevel);

                    // For initial proof of concept validation, we are logging to the console
                    // using the fastest thread method.
                    LogEngine.ILogger logger = new ConsoleLoggerThread();

                    // And we finally send this log on its way.
                    logger.LogOneEvent(
                        logDic[Constant.Source].GetString(),
                        evTimeStamp,
                        logLevel,
                        logDic[Constant.Message].GetString(),
                        meta
                        );

                    return Ok();
                }
                else
                {
                    return BadRequest(kvp.Value);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return BadRequest(ex.Message);
            }
        }


        /// <summary>
        /// Returns log service statistics
        ///     GET: api/LogService
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ContentResult Get()
        {
            ServiceStatistics stats = Statistics.Instance.Get();
            string jsonString = JsonSerializer.Serialize(stats);
            return Content(jsonString, "application/json");
        }

#if INCLUDE_CRUD
        // GET: api/LogService
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/LogService/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            //return "value";

            this.Response.StatusCode = 401;
            return "Hi Mom";
        }

        // PUT: api/LogService/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
            this.Response.StatusCode = 401;
        }

        // DELETE: api/LogService/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
#endif
        private MetaData BuildMetadata(Dictionary<string, dynamic> logDic)
        {
            MetaData meta = new();

            foreach (KeyValuePair<string, dynamic> kvp in logDic)
            {
                if (ReservedKeywords.Contains(kvp.Key, StringComparer.OrdinalIgnoreCase) == true)
                    continue;

                Type t = kvp.Value.GetType();
                Debug.Assert(t.Equals(typeof(System.Text.Json.JsonElement)) == true);
                System.Text.Json.JsonElement element = kvp.Value;

                switch(kvp.Value.ValueKind)
                {
                    case JsonValueKind.Number:
                        meta.Add(kvp.Key, element.GetInt32());
                        break;

                    case JsonValueKind.String:
#pragma warning disable CS8604
                        meta.Add(kvp.Key, element.GetString());
#pragma warning restore CS8604
                        break;

                    default:
                        throw new NotImplementedException("Unknown meta kind: {0}", kvp.Value.ValueKind.ToString());
                }
            }

            return (meta);
        }

        private Level StringToLogLevel(string str)
        {
            Level level;

            if (str == Constant.Error)
                level = Level.Error;
            else if (str == Constant.Warning)
                level = Level.Warning;
            else if (str == Constant.Info)
                level = Level.Info;
            else if (str == Constant.Trace)
                level = Level.Trace;
            else
                throw new Exception(string.Format("Unrecognized log level: {0}", str));

            return (level);
        }

        private KeyValuePair<HttpStatusCode, dynamic> ValidateReceivedLogData(string value)
        {
            KeyValuePair<HttpStatusCode, dynamic> ret;

            var logDic = JsonSerializer.Deserialize<Dictionary<string, dynamic>>(value);

            if (logDic is null)
                ret = new KeyValuePair<HttpStatusCode, dynamic>(HttpStatusCode.BadRequest, "Cannot deserialize received data");
            else if (logDic.ContainsKey(Constant.TimeStamp) == false)
                ret = GetMissingDataReturn(Constant.TimeStamp);
            else if (ValidateDateTimeFormat(Convert.ToString(logDic[Constant.TimeStamp])) == false)
                ret = GetMissingDataReturn(Constant.DateFormat);
            else if (logDic.ContainsKey(Constant.Level) == false)
                ret = GetMissingDataReturn(Constant.Level);
            else if (logDic.ContainsKey(Constant.Message) == false)
                ret = GetMissingDataReturn(Constant.Message);
            else if (logDic.ContainsKey(Constant.Source) == false)
                ret = GetMissingDataReturn(Constant.Source);
            else
                ret = new KeyValuePair<HttpStatusCode, dynamic>(HttpStatusCode.OK, logDic);

            return (ret);
        }

        private bool ValidateDateTimeFormat(string timestamp)
        {
            bool IsValid = true;

            try
            {
                DateTime.ParseExact(timestamp, Constant.DateFormat,
                                       System.Globalization.CultureInfo.InvariantCulture);
            }
            catch(Exception)
            {
                IsValid = false;
            }

            return (IsValid);
        }

        private KeyValuePair<HttpStatusCode, dynamic> GetMissingDataReturn(string missing)
        {
            return(new KeyValuePair<HttpStatusCode, dynamic>(HttpStatusCode.BadRequest,
                string.Format("'{0}' missing from received data", missing)));
        }
    }
}
