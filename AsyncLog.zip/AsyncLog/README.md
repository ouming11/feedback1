# AsyncLog
Tried out performance of various asynchronous logging implementations using C# 11 and .NET 7

The AsyncLogTest is a CLI test harness that displays a meny asking which of the 3 logging methods should be measured for performance.

Specifically which logging method provides the least amount of performance hit to an application. Possible choice are:

1.- Synchronous
2.- Asynhronous
3.- Threadding

The elapsed time in miliseconds gathered from 5 runs of each method on my local machine produced the following data. In each run 800 logs were writen.

Synchronous log method: 422, 440, 449, 429, 440
Asynchrnous log method: 618, 591, 455, 542, 865
Threading log method: 0, 2, 2, 1, 0
