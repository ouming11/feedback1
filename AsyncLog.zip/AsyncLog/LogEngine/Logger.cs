﻿using System;
using System.Threading;

namespace LogEngine
{
	public abstract class Logger: IDisposable, ILogger
    {
        public abstract void Error(string msg);
        public abstract void Warning(string msg);
        public abstract void Info(string msg);
        public abstract void Trace(string msg);
        public abstract void Error(string msg, MetaData meta);
        public abstract void Warning(string msg, MetaData meta);
        public abstract void Info(string msg, MetaData meta);
        public abstract void Trace(string msg, MetaData meta);
        public abstract void LogOneEvent(string source, DateTime dt, Level level, string msg);
        public abstract void LogOneEvent(string source, DateTime dt, Level level, string msg, MetaData meta);

        // The consumer object can call
        // the below dispose method
        public void Dispose()
        {
            // Invoke the above virtual
            // dispose(bool disposing) method
            DisposeResources();

            // Notify the garbage collector
            // about the cleaning event
            GC.SuppressFinalize(this);
        }

        // Gets called by the below dispose method
        // resource cleaning happens here
        public abstract void DisposeResources();
    }
}

