﻿using System;
using System.Diagnostics;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Net.Http.Json;
using System.Dynamic;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Mime;
using System.Text;
using System.Text.Json.Nodes;
using System.Net;
using System.Numerics;
using System.Threading;
using System.Timers;

namespace LogEngine
{
	public class HttpClientLoggerSync : Logger
    {
        /// <summary>
        /// Obtained from the appsettings.json file. Url to use
        /// Key is the base URL
        /// Value is the path
        /// </summary>
        private readonly KeyValuePair<string, string> kvpUrl;
        private System.Timers.Timer? _uploadLogsTimer = null;
        private bool _requestStop = false;

        public HttpClientLoggerSync()
		{
            kvpUrl = ReadHttpLogUrl();
		}

        // Gets called by the below dispose method
        // resource cleaning happens here
        public override void DisposeResources()
        {
            if (_uploadLogsTimer is not null)
            {
                _requestStop = true;
                _uploadLogsTimer.Stop();
                _uploadLogsTimer.Dispose();
                _uploadLogsTimer = null;
            }
        }

        /// <summary>
        /// Output a Error message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public override void Error(string msg)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Error, msg, new MetaData());
        }

        /// <summary>
        /// Output a Error message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public override void Error(string msg, MetaData meta)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Error, msg, meta);
        }

        /// <summary>
        /// Output a Warning message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public override void Warning(string msg)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Warning, msg, new MetaData());
        }

        /// <summary>
        /// Output a Warning message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public override void Warning(string msg, MetaData meta)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Warning, msg, meta);
        }

        /// <summary>
        /// Output a Info message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public override void Info(string msg)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Info, msg, new MetaData());
        }

        /// <summary>
        /// Output a Info message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public override void Info(string msg, MetaData meta)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Info, msg, meta);
        }

        /// <summary>
        /// Output a Trace message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public override void Trace(string msg)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Trace, msg, new MetaData());
        }

        /// <summary>
        /// Output a Trace message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public override void Trace(string msg, MetaData meta)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Trace, msg, meta);
        }

        /// <summary>
        /// The logic implemented by this function is to attempt to send the
        /// log event over HTTP. If this fails for some reason then place this
        /// log into a local temporary storage and wait for a configurable
        /// number of minutes before attempting another HTTP connection.
        ///
        /// If a connection was successful, then go through all temporary storage
        /// stored events and upload them via HTTP.
        ///
        /// This logic can be tricky because
        /// (a) We cannot spend a lot of time uploading megabytes of data because
        ///     the existing connection will timeout.
        /// (b) It could be that while uploading the connection is severed again.
        /// 
        /// </summary>
        /// <param name="source">Event originating source</param>
        /// <param name="dt">Timestamp of the event</param>
        /// <param name="level">Log level</param>
        /// <param name="msg">Message describing the event</param>
        public override void LogOneEvent(string source, DateTime dt, Level level, string msg)
        {
            LogOneEvent(source, dt, level, msg, new MetaData());
        }

        /// <summary>
        /// The logic implemented by this function is to attempt to send the
        /// log event over HTTP. If this fails for some reason then place this
        /// log into a local temporary storage and wait for a configurable
        /// number of minutes before attempting another HTTP connection.
        ///
        /// If a connection was successful, then go through all temporary storage
        /// stored events and upload them via HTTP.
        ///
        /// This logic can be tricky because
        /// (a) We cannot spend a lot of time uploading megabytes of data because
        ///     the existing connection will timeout.
        /// (b) It could be that while uploading the connection is severed again.
        /// 
        /// </summary>
        /// <param name="source">Event originating source</param>
        /// <param name="dt">Timestamp of the event</param>
        /// <param name="level">Log level</param>
        /// <param name="msg">Message describing the event</param>
        /// <param name="meta">Optional metadata</param>
        public async override void LogOneEvent(string source, DateTime dt, Level level, string msg, MetaData meta)
        {
            if (await HttpSendAsync(source, dt, level, msg, meta) == false)
            {
                using (FileLogger? fileLogger = new FileLogger())
                {
                    fileLogger.LogOneEvent(source, dt, level, msg, meta);

                    if (_uploadLogsTimer is null)
                    {
                        _uploadLogsTimer = new System.Timers.Timer();
                        _uploadLogsTimer.Interval = 5000;
                        _uploadLogsTimer.Elapsed += UploadLocalStoreAndForward;
                        _uploadLogsTimer.AutoReset = false;
                        _uploadLogsTimer.Start();
                    }
                }
            }
        }

        /// <summary>
        /// This method is called periodically by a timer function. When it is
        /// called a BlockSize of the l=oldest events are read fron the local
        /// store and forward, if there are any, and they are attempted to be
        /// uploaded to the HTTP server.
        /// If uploading succeeds, then the block is deleted.
        /// Note that we are intentionally not uploading all local store and
        /// forward events as these could be many and we do not want to block
        /// for too long.
        /// </summary>
        /// <param name="stateInfo">FileLogger object from timer</param>
        public async void UploadLocalStoreAndForward(
            Object? stateInfo,
            System.Timers.ElapsedEventArgs e
            )
        {
            const int BlockSize = 100;

            using (FileLogger? fileLogger = new FileLogger())
            {
                // We first need to get a list of local log files created
                // for all sources

                string[] AllLogSources = FileLogSource.GetAllLogSources();

                foreach (string source in AllLogSources)
                {
                    FileLogSource logSource = new(source);

                    // Then we need to empty each set of log files for each source
                    // and attempt again to upload them

                    FileBlock fileBlock = logSource.GetOldestEntries(BlockSize);
                    FileBlock uploaded = new();

                    int count = fileBlock.Count();
                    System.Diagnostics.Debug.Assert(count <= BlockSize);

                    for (int i = 0; i < count; i++)
                    {
                        string fullPath;
                        int lineNum;
                        string line;

                        bool success = fileBlock.GetAt(i, out fullPath, out lineNum, out line);
                        System.Diagnostics.Debug.Assert(success == true);
                        System.Diagnostics.Debug.Assert(fullPath.Length > 0);
                        System.Diagnostics.Debug.Assert(lineNum != -1);
                        System.Diagnostics.Debug.Assert(line.Length > 0);

                        LogItem logItem = new(line);

                        success = await HttpSendAsync(logItem.Source, logItem.Timestamp,
                                                logItem.Level, logItem.Message,
                                                logItem.Meta
                                                );

                        if (success == true)
                        {
                            uploaded.Add(fullPath, lineNum, line);
                        }
                    }

                    if (count > 0)
                    {
                        // All the uploaded log events, these should be cleared from
                        // the log files so we do not attempt to upload them again.
                        uploaded.DeleteAll();
                        break;
                    }
                }

                if (_requestStop == false && _uploadLogsTimer is not null)
                {
                    _uploadLogsTimer.Start();//restart the timer
                }
            }
        }

        /// <summary>
        /// Sends the event over HTTP to its destination collection point
        /// </summary>
        /// <param name="source">Event originating source</param>
        /// <param name="dt">Timestamp of the event</param>
        /// <param name="level">Log level</param>
        /// <param name="msg">Message describing the event</param>
        /// <param name="meta">Optional metadata</param>
        /// <returns></returns>
        public async Task<bool> HttpSendAsync(
            string source,
            DateTime dt,
            Level level,
            string msg,
            MetaData ? meta = null
            )
        {
            bool Success = false;

            try
            {
                using (var handler = new HttpClientHandler())
                {
                    // Bypass the certificate
                    handler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };

                    dynamic logData = new ExpandoObject();
                    logData.time = dt.ToString(Constant.DateFormat);
                    logData.level = level.ToString();
                    logData.message = msg;
                    logData.source = source;
                    var dic = (IDictionary<string, object>)logData;
                    AppendMetadata(ref dic, meta);
                    string strData = JsonSerializer.Serialize<IDictionary<string, object>>(dic);

                    // Super important that in client the body should be formatted as
                    // "{\"saying\": \"hello!\"}"

                    strData = string.Format("\"{0}\"", strData.Replace("\"", "\\\""));

                    Console.WriteLine("\nSending: " + strData);

                    using (var client = new HttpClient(handler))
                    {
                        string fullUrl = string.Format("Calling: {0}{1}", kvpUrl.Key, kvpUrl.Value);

                        client.BaseAddress = new Uri(kvpUrl.Key);

                        var response = await client.PostAsync(
                                kvpUrl.Value,
                                new StringContent(strData, System.Text.Encoding.UTF8, "application/json")
                                );

                        response.EnsureSuccessStatusCode();

                        string responseBody = await response.Content.ReadAsStringAsync();

                        if (responseBody.Length > 0)
                        {
                            Console.WriteLine("Received: " + responseBody);

                            //dynamic? json = JsonSerializer.Deserialize<dynamic>(responseBody);
                            //System.Diagnostics.Debug.Assert(json is not null);
                        }
                        else
                        {
                            Console.WriteLine("Success");
                        }
                    }

                    Success = true;
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return (Success);
        }

        private void AppendMetadata(ref IDictionary<string, object>  dic, MetaData? meta, string metaNamePrefix = "")
        {
            if (meta is not null)
            {
                List<KeyValuePair<string, dynamic>> listKvp = meta.GetMetadata();

                foreach(KeyValuePair<string, dynamic> kvp in listKvp)
                {
                    if (kvp.Value.GetType() == typeof(LogEngine.MetaData))
                    {
                        AppendMetadata(ref dic, kvp.Value, string.Format("{0}.", kvp.Key));
                    }
                    else
                    {
                        dic.Add(string.Format("{0}{1}", metaNamePrefix, kvp.Key), kvp.Value);
                    }
                }
            }
        }

        private KeyValuePair<string,string> ReadHttpLogUrl()
        {
            // Get the section within the appsettings.json file that contains
            // file logging settings
            var configBuilder = new ConfigurationBuilder().AddJsonFile("appsettings.json");
            IConfiguration configuration = configBuilder.Build();
            IConfigurationSection consoleSection = configuration.GetSection("HttpLoggerOptions");

            string? BaseAddress = consoleSection.GetValue<string>("BaseAddress");
            string? url = consoleSection.GetValue<string>("Url");

            if (BaseAddress is null)
            {
                throw new Exception("HttpLoggerOptions.BaseAddress not found in appsettings.json");
            }

            if (url is null)
            {
                throw new Exception("HttpLoggerOptions.Url not found in appsettings.json");
            }

            return (new KeyValuePair<string, string>(BaseAddress, url));
        }
    }
}

