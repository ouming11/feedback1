﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;

namespace LogEngine
{
	public class Helper
	{
		public Helper()
		{
		}

        /// <summary>
        /// We make use of Span<T> inside a foreach loop to count the character
        /// occurrences. The string class has a built-in method that returns a
        /// Span<Char>. Span<T> performs better than the string class because it
        /// is always allocated on the stack. The garbage collector does not have
        /// to suspend execution to clean up objects on the heap and hence often,
        /// the application runs faster.
        /// </summary>
        /// <param name="source">Source string to find char in</param>
        /// <param name="toFind">Character to find</param>
        /// <returns></returns>
        public static int CountChars(string source, char toFind)
        {
            int count = 0;

            foreach (var c in source.AsSpan())
            {
                if (c == toFind)
                    count++;
            }

            return count;
        }

        public static string CallingProcessName()
        {
#pragma warning disable CS8600
#pragma warning disable CS8602
            string name = System.Reflection.Assembly.GetEntryAssembly().GetName().Name;
#pragma warning restore CS8602
#pragma warning restore CS8600

            return (name is not null) ? name : string.Empty;
        }

        public static string CallingProcessPath()
        {
            //var process = Process.GetCurrentProcess(); // Or whatever method you are using
#pragma warning disable CS8602
            //string? fullPath = process.MainModule.FileName;
            Assembly? ass = System.Reflection.Assembly.GetEntryAssembly();

            string? fullPath = ass.Location;

#pragma warning restore CS8602

            fullPath = Path.GetDirectoryName(fullPath);
            return ((fullPath is not null) ? fullPath : string.Empty);
        }

        /// <summary>
        /// If appears to be a relative path
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static bool IsRelativePath(string str)
        {
            return (str.Length > 0 && str[0] == '.') ? true : false;
        }

        public static string TrimRelativePart(string str)
        {
            string strRet = string.Empty;

            for(int i = 0; i < str.Length; i++)
            {
                if (str[i] == '.' || str[i] == '/' || str[i] == '\\')
                {
                    continue;
                }

                strRet = str.Substring(i);
                break;
            }

            return (strRet);
        }
    }
}

