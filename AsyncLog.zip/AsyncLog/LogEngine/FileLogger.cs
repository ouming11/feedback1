﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LogEngine
{
	public class FileLogger : Logger
    {
        private static readonly object _listAccess = new object();
        private Dictionary<string, LinkedList<LogItem>> _logEvents = new();
        private Thread _thread;
        private AutoResetEvent _threadWakeup = new(false);
        private AutoResetEvent _threadExit = new(false);
        private WaitHandle[] _waitHandles;
        private bool IsDisabled = false;

        public FileLogger() 
		{
            _waitHandles = new WaitHandle[]
            {
                _threadWakeup,
                _threadExit
            };

            _thread = new Thread(new ThreadStart(WorkerThread));
            _thread.Name = "File Log Thread";
            _thread.Start();
        }

        /// <summary>
        /// Output a Error message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public override void Error(string msg)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Error, msg, new MetaData());
        }

        /// <summary>
        /// Output a Error message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public override void Error(string msg, MetaData meta)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Error, msg, meta);
        }

        /// <summary>
        /// Output a Warning message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public override void Warning(string msg)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Warning, msg, new MetaData());
        }

        /// <summary>
        /// Output a Warning message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public override void Warning(string msg, MetaData meta)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Warning, msg, meta);
        }

        /// <summary>
        /// Output a Info message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public override void Info(string msg)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Info, msg, new MetaData());
        }

        /// <summary>
        /// Output a Info message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public override void Info(string msg, MetaData meta)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Info, msg, meta);
        }

        /// <summary>
        /// Output a Debug message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public override void Trace(string msg)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Trace, msg);
        }

        /// <summary>
        /// Output a Debug message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public override void Trace(string msg, MetaData meta)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Trace, msg, meta);
        }

        // Gets called by the below dispose method
        // resource cleaning happens here
        public override void DisposeResources()
        {
            _threadExit.Set();
            _thread.Join();
        }

        /// <summary>
        /// When greater control is needed at the expense of providing
        /// more parameters, this function can be used.
        /// </summary>
        /// <param name="source">Source of this event</param>
        /// <param name="dt">Timestamp of the event. Ideally in UTC</param>
        /// <param name="level">One of the Log Level enumerators</param>
        /// <param name="msg">Log message</param>
        public override void LogOneEvent(
            string source, DateTime dt, Level level, string msg
            )
        {
            LogOneEvent(source, dt, level, msg, new MetaData());
        }

        /// <summary>
        /// When greater control is needed at the expense of providing
        /// more parameters, this function can be used.
        /// </summary>
        /// <param name="dt">Timestamp of the event. Ideally in UTC</param>
        /// <param name="level">One of the Log Level enumerators</param>
        /// <param name="msg">Log message</param>
        /// <param name="meta">Optional associated metadata</param>
        public override void LogOneEvent(string source, DateTime dt, Level level, string msg, MetaData meta)
        {
            if (IsDisabled == false)
            {
                LogItem oneItem = new()
                {
                    Source = source,
                    Timestamp = dt,
                    Level = level,
                    Message = msg,
                    Meta = meta
                };

                lock (_listAccess)
                {
                    if (_logEvents.ContainsKey(source) == false)
                    {
                        _logEvents.Add(source, new());
                    }

                    LinkedList<LogItem> logEvList = _logEvents[source];
                    logEvList.AddLast(oneItem);
                }

                _threadWakeup.Set();
            }
        }

        /// <summary>
        /// Worker thread that is responsible for picking log items from its
        /// internal queue and persist them
        /// </summary>
        private void WorkerThread()
        {
            var LogSrcDic = new Dictionary<string, FileLogSource>();
            int eventTriggered;

            do
            {
                eventTriggered = WaitHandle.WaitAny(_waitHandles);

                // First we empty to entire queue of all log events for each
                // log source and put them into a linked list of key/value
                // pairs where the key is the log source and the value is
                // an array of logs to add to the log file for that log source

                LinkedList<KeyValuePair<string, LinkedList<LogItem>>> logList = new();

                lock (_listAccess)
                {
                    foreach(KeyValuePair<string, LinkedList<LogItem>> kvp in _logEvents)
                    {
                        KeyValuePair<string, LinkedList<LogItem>> kvpLog = new(kvp.Key, kvp.Value);
                        logList.AddLast(kvpLog);
                    }

                    // We intentionally reinitialize the dictionary of
                    // log events as we are going to do file writes in
                    // batches
                    _logEvents = new();
                }

                try
                {
                    // This is now a nice list that is already organized
                    // by source. So we just go through each, ensure that
                    // there is a log source writer for each log source
                    // and we pass it an array of strings to write.
                    foreach (KeyValuePair<string, LinkedList<LogItem>> kvpLog in logList)
                    {
                        if (LogSrcDic.ContainsKey(kvpLog.Key) == false)
                        {
                            LogSrcDic.Add(kvpLog.Key, new FileLogSource(kvpLog.Key));
                        }

                        FileLogSource log = LogSrcDic[kvpLog.Key];
                        System.Diagnostics.Debug.Assert(log is not null);
                        log.WriteLines(kvpLog.Value);
                    }
                }
                catch(Exception ex)
                {
                    // Error happened when writing. Possible cause could be
                    // out of storage. The decision I made on how to handle
                    // this condition is to alert, disable this subsystem
                    // and terminate this worker thread.
                    IsDisabled = true;
                    Console.WriteLine("File logger error:");
                    Console.WriteLine(ex.Message);
                    break;
                }
            } while (eventTriggered == 0);

            Console.WriteLine("FileLogger WorkerThread() terminated");
         }
    }
}
