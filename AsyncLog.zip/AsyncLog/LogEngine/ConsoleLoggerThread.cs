﻿using System;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LogEngine
{
    /// <summary>
    /// An asynchronous implementation of console logging that uses a worker
    /// thread that picks items to log from an queue. This method provides
    /// the best possible performance. 5000 events in 29ms
    /// </summary>
	public class ConsoleLoggerThread : Logger
    {
        private static readonly object _listAccess = new object();
        private LinkedList<LogItem> _logEvents = new();
        private Thread _thread;
        private AutoResetEvent _threadWakeup = new(false);
        private AutoResetEvent _threadExit = new(false);
        private WaitHandle[] _waitHandles;
        private ConsoleLogger _consoleLogger;

        /// <summary>
        /// Constructor that initializes the Console logger
        /// </summary>
        /// <param name="verbose">True if Debug logging should be enabled</param>
        /// <param name="consoleColors">Optional colors to use for console output </param>
        public ConsoleLoggerThread(bool verbose = false, ConsoleColors? consoleColors = null)
        {
            _consoleLogger = new(verbose, consoleColors);

            _waitHandles = new WaitHandle[]
            {
                _threadWakeup,
                _threadExit
            };

            _thread = new Thread(new ThreadStart(WorkerThread));
            _thread.Name = "Console Log Thread";
            _thread.Start();
        }

        // Gets called by the below dispose method
        // resource cleaning happens here
        public override void DisposeResources()
        {
            _threadExit.Set();
            _thread.Join();
        }

        /// <summary>
        /// Output a Debug message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public override void Trace(string msg)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Trace, msg, new MetaData());
        }

        /// <summary>
        /// Output a Debug message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public override void Trace(string msg, MetaData meta)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Trace, msg, meta);
        }

        /// <summary>
        /// Output a Error message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public override void Error(string msg)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Error, msg);
        }

        /// <summary>
        /// Output a Error message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public override void Error(string msg, MetaData meta)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Error, msg, meta);
        }

        /// <summary>
        /// Output a Info message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public override void Info(string msg)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Info, msg, new MetaData());
        }

        /// <summary>
        /// Output a Info message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public override void Info(string msg, MetaData meta)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Info, msg, meta);
        }

        /// <summary>
        /// Output a Warning message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public override void Warning(string msg)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Warning, msg, new MetaData());
        }

        /// <summary>
        /// Output a Warning message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public override void Warning(string msg, MetaData meta)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Warning, msg, meta);
        }

        /// <summary>
        /// When greater control is needed at the expense of providing
        /// more parameters, this function can be used.
        /// </summary>
        /// <param name="dt">Timestamp of the event. Ideally in UTC</param>
        /// <param name="level">One of the Log Level enumerators</param>
        /// <param name="msg">Log message</param>
        public override void LogOneEvent(string source, DateTime dt, Level level, string msg)
        {
            LogOneEvent(source, dt, level, msg, new MetaData());
        }

        /// <summary>
        /// When greater control is needed at the expense of providing
        /// more parameters, this function can be used.
        /// </summary>
        /// <param name="dt">Timestamp of the event. Ideally in UTC</param>
        /// <param name="level">One of the Log Level enumerators</param>
        /// <param name="msg">Log message</param>
        /// <param name="meta">Associated metadata</param>
        public override void LogOneEvent(string source, DateTime dt, Level level, string msg, MetaData meta)
        {
            LogItem oneItem = new()
            {
                Source = source,
                Timestamp = dt,
                Level = level,
                Message = msg,
                Meta = (meta is not null) ? meta : new MetaData()
            };

            lock (_listAccess)
            {
                _logEvents.AddFirst(oneItem);
            }

            _threadWakeup.Set();
        }

        /// <summary>
        /// Worker thread that is responsible for picking log items from its
        /// internal queue and persist them
        /// </summary>
        private void WorkerThread()
        {
            int eventTriggered;

            do
            {
                eventTriggered = WaitHandle.WaitAny(_waitHandles);

                LogItem? oneItem;

                do
                {
                    oneItem = null;

                    lock (_listAccess)
                    {
                        if (_logEvents.Count > 0)
                        {
                            oneItem = _logEvents.Last();
                            _logEvents.RemoveLast();
                        }
                    }

                    if (oneItem != null)
                    {
                        _consoleLogger.LogOneEvent(
                                oneItem.Source,
                                oneItem.Timestamp,
                                oneItem.Level,
                                oneItem.Message,
                                oneItem.Meta
                                );
                    }
                } while (oneItem != null);

            } while (eventTriggered == 0);
        }
    }
}
