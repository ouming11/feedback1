﻿using System;
using System.Diagnostics;
using System.Text;
using System.Xml.Linq;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace LogEngine
{
	public class LogItem
	{
        /// <summary>
        /// This class can be initialized either from a CSV or a JSON string
        /// </summary>
        /// <param name="strInit"></param>
        public LogItem(string ? strInit = null)
        {
            Source = string.Empty;
            Level = Level.Info;
            Message = string.Empty;
            Meta = new MetaData();
            Timestamp = DateTime.MinValue;

            if (strInit is not null)
            {
                InitializeFromString(strInit);
            }
        }

        public string Source { get; set; }
        public DateTime Timestamp { get; set; }
        public Level Level { get; set; }
        public string Message { get; set; }
        public MetaData Meta { get; set; }

        public int Length(bool calculateAsCsv)
        {
            string str;

            if (calculateAsCsv == true)
                str = ToCsvString();
            else
                str = ToJsonString();

            return (str.Length);
        }

        public string ToJsonString()
        {
            StringBuilder sb = new("{");

            string tmp = Timestamp.ToString(Constant.DateFormat);
            sb.Append($"\"time\": \"{tmp}\", ");
            sb.Append($"\"level\": \"{Level.ToString()}\", ");
            sb.Append($"\"source\": \"{Source}\", ");
            sb.Append($"\"message\": \"{Message}\"");

            if (Meta is not null)
            {
                AppendMetadata(ref sb, Meta, ", \"{0}\": \"{1}\"");
            }

            sb.Append("}");

            return (sb.ToString());
        }

        public string ToCsvString()
        {
            StringBuilder sb = new();

            string tmp = Timestamp.ToString(Constant.DateFormat);
            sb.Append($"time={tmp},");
            sb.Append($"level={Level.ToString()},");
            sb.Append($"source={Source},");
            sb.Append($"message={Message}");

            if (Meta is not null)
            {
                AppendMetadata(ref sb, Meta, ",{0}={1}");
            }

            return (sb.ToString());
        }

        #region Private
        private void InitializeFromString(string strInit)
        {
            bool IsJsonFormatted = (strInit[0] == '{') ? true : false;

            string[] elements = strInit.Split(',');

            foreach (string element in elements)
            {
                KeyValuePair<string, string> kvp;

                if (IsJsonFormatted == true)
                    kvp = LogItem.GetJsonElementPair(element);
                else
                    kvp = LogItem.GetCsvElementPair(element);

                if (kvp.Key.Equals(Constant.Time, StringComparison.OrdinalIgnoreCase) == true)
                {
                    DateTime time;

                    if (DateTime.TryParse(kvp.Value, out time) == false)
                    {
                        throw new Exception(string.Format("Internal error parsing timestamp:", kvp.Value));
                    }

                    Timestamp = time;
                }
                else if (kvp.Key.Equals(Constant.Level, StringComparison.OrdinalIgnoreCase) == true)
                {
                    if (kvp.Value.Equals(Constant.Error, StringComparison.OrdinalIgnoreCase) == true)
                        Level = Level.Error;
                    else if (kvp.Value.Equals(Constant.Warning, StringComparison.OrdinalIgnoreCase) == true)
                        Level = Level.Warning;
                    else if (kvp.Value.Equals(Constant.Info, StringComparison.OrdinalIgnoreCase) == true)
                        Level = Level.Info;
                    else if (kvp.Value.Equals(Constant.Trace, StringComparison.OrdinalIgnoreCase) == true)
                        Level = Level.Trace;
                    else
                        throw new Exception(string.Format("Internal error parsing level:", kvp.Value));
                }
                else if (kvp.Key.Equals(Constant.Source, StringComparison.OrdinalIgnoreCase) == true)
                {
                    Source = kvp.Value;
                }
                else if (kvp.Key.Equals(Constant.Message, StringComparison.OrdinalIgnoreCase) == true)
                {
                    Message = kvp.Value;
                }
                else
                {
                    // Metadata
                    if (Meta is null)
                        Meta = new MetaData();

                    int count = Helper.CountChars(kvp.Key, '.');
                    string key = kvp.Key;

                    if (count > 0)
                    {
                        int lastIdx = kvp.Key.LastIndexOf('.');
                        string metaNames = kvp.Key.Substring(0, lastIdx);
                        key = kvp.Key.Substring(lastIdx + 1);
                        Meta.CreateChildren(metaNames).Add(key, kvp.Value);
                    }
                    else
                    {
                        Meta.Add(key, kvp.Value);
                    }
                }
            }
        }

        private static KeyValuePair<string, string> GetCsvElementPair(string element)
        {
            int idx = element.IndexOf('=');
            Debug.Assert(idx != -1);
            string key = element.Substring(0, idx - 1);
            Debug.Assert(key.Length > 0);
            string value = element.Substring(idx);
            Debug.Assert(value.Length > 0);

            return (new KeyValuePair<string, string>(key.Trim(), value.Trim()));
        }

        private static KeyValuePair<string, string> GetJsonElementPair(string element)
        {
            int firstIdx = element.IndexOf(':');
            string key = element.Substring(0, firstIdx);
            string value = element.Substring(firstIdx + 1);

            firstIdx = key.IndexOf('"');
            int lastIdx = key.LastIndexOf('"');
            key = key.Substring(firstIdx + 1, lastIdx - firstIdx - 1);

            firstIdx = value.IndexOf('"');
            lastIdx = value.LastIndexOf('"');
            value = value.Substring(firstIdx + 1, lastIdx - firstIdx - 1);

            return (new KeyValuePair<string, string>(key.Trim(), value.Trim()));
        }

        private void AppendMetadata(ref StringBuilder sb, MetaData meta,
            string format, string metaNamePrefix = ""
            )
        {
            List<KeyValuePair<string, dynamic>> listMeta = meta.GetMetadata();

            foreach (KeyValuePair<string, dynamic> kvp in listMeta)
            {
                if (kvp.Value.GetType() == typeof(MetaData))
                {
                    MetaData childMeta = kvp.Value;

                    AppendMetadata(ref sb, childMeta, format,
                        string.Format("{0}{1}.", metaNamePrefix, kvp.Key));
                }
                else
                {
                    string name = string.Format("{0}{1}", metaNamePrefix, kvp.Key);
                    sb.Append(string.Format(format, name, kvp.Value.ToString()));
                }
            }
        }

        #endregion
    }
}
