﻿using System;
namespace LogEngine
{
    /// <summary>
    /// Console color class that is used to optionally specify
    /// colors to the console output
    /// </summary>
    public class ConsoleColors
    {
        public ConsoleColor Timestamp { get; set; }
        public ConsoleColor ErrorLevel { get; set; }
        public ConsoleColor WarningLevel { get; set; }
        public ConsoleColor InfoLevel { get; set; }
        public ConsoleColor TraceLevel { get; set; }
        public ConsoleColor Message { get; set; }
        public ConsoleColor Metadata { get; set; }
    }
}
