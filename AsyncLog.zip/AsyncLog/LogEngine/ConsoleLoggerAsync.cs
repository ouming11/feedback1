﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LogEngine
{
    /// <summary>
    /// .NET asynchronous eevent logging class that derives from the synchronous
    /// event logging base class. Because each log event creates a thread that
    /// is short lived, it is not efficient and performance improvements are
    /// negligible. There I would not recommend using it.
    /// </summary>
    public class ConsoleLoggerAsync : Logger
    {
        #region Private Region
        private Mutex _mutex;
        private ConsoleLogger _consoleLogger;
        #endregion

        /// <summary>
        /// Constructor that initializes the Console logger
        /// </summary>
        /// <param name="verbose">True if Debug logging should be enabled</param>
        /// <param name="consoleColors">Optional colors to use for console output </param>
        public ConsoleLoggerAsync(bool verbose = false, ConsoleColors? consoleColors = null)
        {
            _consoleLogger = new(verbose, consoleColors);
            _mutex = new Mutex();
        }

        // Gets called by the below dispose method
        // resource cleaning happens here
        public override void DisposeResources()
        {
            // Nothing to do in this class
        }

        /// <summary>
        /// Output a Debug message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public async override void Trace(string msg)
        {
            await OutputMessageAsync(DateTime.UtcNow, Level.Trace, Helper.CallingProcessName(), msg, new MetaData());
        }

        /// <summary>
        /// Output a Debug message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public async override void Trace(string msg, MetaData meta)
        {
            await OutputMessageAsync(DateTime.UtcNow, Level.Trace, Helper.CallingProcessName(), msg, meta);
        }

        /// <summary>
        /// Output a Error message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public async override void Error(string msg)
        {
            await OutputMessageAsync(DateTime.UtcNow, Level.Error, Helper.CallingProcessName(), msg, new MetaData());
        }

        /// <summary>
        /// Output a Error message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public async override void Error(string msg, MetaData meta)
        {
            await OutputMessageAsync(DateTime.UtcNow, Level.Error, Helper.CallingProcessName(), msg, meta);
        }

        /// <summary>
        /// Output a Info message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public async override void Info(string msg)
        {
            await OutputMessageAsync(DateTime.UtcNow, Level.Info, Helper.CallingProcessName(), msg, new MetaData());
        }

        /// <summary>
        /// Output a Info message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public async override void Info(string msg, MetaData meta)
        {
            await OutputMessageAsync(DateTime.UtcNow, Level.Info, Helper.CallingProcessName(), msg, meta);
        }

        /// <summary>
        /// Output a Warning message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public async override void Warning(string msg)
        {
            await OutputMessageAsync(DateTime.UtcNow, Level.Warning, Helper.CallingProcessName(), msg, new MetaData());
        }

        /// <summary>
        /// Output a Warning message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public async override void Warning(string msg, MetaData meta)
        {
            await OutputMessageAsync(DateTime.UtcNow, Level.Warning, Helper.CallingProcessName(), msg, meta);
        }

        /// <summary>
        /// When greater control is needed at the expense of providing
        /// more parameters, this function can be used.
        /// </summary>
        /// <param name="source">Source of this event</param>
        /// <param name="dt">Timestamp of the event. Ideally in UTC</param>
        /// <param name="level">One of the Log Level enumerators</param>
        /// <param name="msg">Log message</param>
        public async override void LogOneEvent(
            string source, DateTime dt, Level level, string msg
            )
        {
            await OutputMessageAsync(dt, Level.Warning, source, msg, new MetaData());
        }

        /// <summary>
        /// When greater control is needed at the expense of providing
        /// more parameters, this function can be used.
        /// </summary>
        /// <param name="source">Source of this event</param>
        /// <param name="dt">Timestamp of the event. Ideally in UTC</param>
        /// <param name="level">One of the Log Level enumerators</param>
        /// <param name="msg">Log message</param>
        /// <param name="meta">Associated metadata</param>
        public async override void LogOneEvent(
            string source, DateTime dt, Level level, string msg,
            MetaData meta
            )
        {
            await OutputMessageAsync(dt, Level.Warning, source, msg, meta);
        }

        /// <summary>
        /// Builds a list of strings coupled with their color codes to display
        /// </summary>
        /// <param name="level">String indicating the log level of message</param>
        /// <param name="msg">Message to shot</param>
        /// <param name="meta">Optional associated metadata</param>
        /// <exception cref="Exception">In case of an internal error</exception>
        private async Task<bool> OutputMessageAsync(DateTime dt, Level level, string source, string msg, MetaData? meta)
        {
            await Task.Run(() =>
            {
                _mutex.WaitOne();
                _consoleLogger.LogOneEvent(source, dt, level, msg, meta);
                _mutex.ReleaseMutex();
            });

            return true;
        }
    }
}
