﻿namespace LogEngine
{
    public enum Level
    {
        Error,
        Warning,
        Info,
        Trace
    }

    public interface ILogger
    {
        void Error(string msg);
        void Warning(string msg);
        void Info(string msg);
        void Trace(string msg);
        void Error(string msg, MetaData meta);
        void Warning(string msg, MetaData meta);
        void Info(string msg, MetaData meta);
        void Trace(string msg, MetaData meta);
        void LogOneEvent(string source, DateTime dt, Level level, string msg);
        void LogOneEvent(string source, DateTime dt, Level level, string msg, MetaData meta);
        void DisposeResources();
    }
}
