﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Runtime.Serialization.Formatters.Binary;

namespace LogEngine
{
    public class MetaData
    {
        private List<KeyValuePair<string, dynamic>> _meta;

        public MetaData(MetaData? src = null)
		{
			_meta = new();

            if (src is not null)
            {
                CloneMetadata(src);
            }
        }

        private void CloneMetadata(MetaData meta)
        {
            List<KeyValuePair<string, dynamic>> srcMeta = meta.GetMetadata();

            foreach (KeyValuePair<string, dynamic> kvp in srcMeta)
            {
                if (kvp.Value.GetType() == typeof(MetaData))
                {
                    MetaData child = kvp.Value;
                    CloneMetadata(child);
                }
                else
                {
                    _meta.Add(new KeyValuePair<string, dynamic>(kvp.Key, kvp.Value));
                }
            }
        }

        public int Count()
        {
            return _meta.Count();
        }

		public void Add(string key, string value)
		{
			_meta.Add(new KeyValuePair<string, dynamic>(key, value));
		}

        public void Add(string key, int value)
        {
            _meta.Add(new KeyValuePair<string, dynamic>(key, value));
        }

        public int Length()
        {
            return (MetadataLength(this));
        }

        private static int MetadataLength(MetaData src)
        {
            int len = 0;

            foreach (KeyValuePair<string, dynamic> oneMeta in src._meta)
            {
                len += oneMeta.Key.Length;

                if (oneMeta.Value.GetType() == typeof(MetaData))
                {
                    len += MetadataLength(oneMeta.Value);
                }
                else
                {
                    len += oneMeta.Value.ToString().Length;
                }
            }

            return (len);
        }

        public MetaData CreateChild(string name)
		{
			MetaData child = new();

            _meta.Add(new KeyValuePair<string, dynamic>(name, child));

            return (child);
        }

        public MetaData CreateChildren(string name)
        {
            MetaData mommy = this;
            string[] metaElements = name.Split('.');

            foreach (string metaElement in metaElements)
            {
                mommy = MetaData.MakeChildIfNotFound(mommy, metaElement);
            }

            return (mommy);
        }

        private static MetaData MakeChildIfNotFound(MetaData mommy, string name)
        {
            bool found = false;
            MetaData ret = new();

            Debug.Assert(mommy is not null);

            foreach (KeyValuePair<string, dynamic> kvp in mommy._meta)
            {
                if (kvp.Key.Equals(name) == true)
                {
                    ret = kvp.Value;
                    found = true;
                    break;
                }
            }

            if (found == false)
                ret = mommy.CreateChild(name);

            return (ret);
        }

        public List<KeyValuePair<string, dynamic>> GetMetadata()
        {
            return (_meta);
        }
    }
}

