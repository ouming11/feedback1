﻿using System;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;

namespace LogEngine
{
	public class FileLogSettings
    {
        public const int MaxFileCountPerSource = 100;
        public const int MaxFileSizeMbPerSource = 10;
		public string RootLogDir { get; set; }
        public int FileCountPerSource { get; set; }
        public int FileSizeMbPerSource { get; set; }
        public bool FileLogOutputCsv{get { return (logAsCsv); }}
        public bool FileLogOutputJson { get { return (!logAsCsv); } }

        private bool logAsCsv = false;

        /// <summary>
        /// Reads and validates the configuration information provided to the
        /// applicaiton in the appsettings.json file
        /// </summary>
        /// <exception cref="Exception"></exception>
		public FileLogSettings()
		{
            RootLogDir = string.Empty;
            FileCountPerSource = -1;
            FileSizeMbPerSource = -1;

            // Get the section within the appsettings.json file that contains
            // file logging settings
            var configBuilder = new ConfigurationBuilder().AddJsonFile("appsettings.json");
            IConfiguration configuration = configBuilder.Build();
            IConfigurationSection consoleSection = configuration.GetSection("FileLoggerOptions");

            // RootLogDir contains the relative or specific root directory
            // where subdirectories should be created for each log source
            string ? str = consoleSection.GetValue<string>("RootLogDir");

            if (str is null)
            {
                throw new Exception("RootLogDir not found in appsettings.json");
            }

            // Ensure that the specified directory can be resolved and created
            // if it does not already exists
            BuildLogDirPath(str);

            // Get the number of files that should be part of a file rotation
            // and validate that this value is not larger than a maximum
            // reasonable value determined by the meister
            int ? i = consoleSection.GetValue<int>("FileCountPerSource");

            if (i is null || i < 0)
            {
                throw new Exception("FileCountPerSource not found in appsettings.json");
            }
            else if (i > MaxFileCountPerSource)
            {
                throw new Exception(string.Format("MaxFileCountPerSource in appsettings.json cannot be larger than {0}", MaxFileCountPerSource));
            }

            FileCountPerSource = (int)i;

            // Get the file size of each log file that it should be allowed
            // to grow to in megabytes. If this value is larger than a maximum
            // reasonable value then fail.
            i = consoleSection.GetValue<int>("FileSizeMbPerSource");

            if (i is null || i < 0)
            {
                throw new Exception("FileSizeMbPerSource not found in appsettings.json");
            }
            else if (i > MaxFileSizeMbPerSource)
            {
                throw new Exception(string.Format("FileSizeMbPerSource in appsettings.json cannot be larger than {0}", MaxFileSizeMbPerSource));
            }

            FileSizeMbPerSource = (int)i;

            logAsCsv = consoleSection.GetValue<bool>("FileLogOutputCsv");
        }

        /// <summary>
        /// Builds the full path to the log directory and creates it in case
        /// it does not exists. This is the root directory under which
        /// subdirectories are created, one for each source type.
        /// </summary>
        /// <param name="logPath">Either relative or full path to the log dir.</param>
        private void BuildLogDirPath(string logPath)
        {
            if (Helper.IsRelativePath(logPath) == true)
            {
                string root = Helper.CallingProcessPath();
                string subDir = Helper.TrimRelativePart(logPath);

                RootLogDir = Path.Combine(root, subDir);
            }
            else
            {
                RootLogDir = logPath;
            }

            if (Directory.Exists(RootLogDir) == false)
            {
                Directory.CreateDirectory(RootLogDir);
            }
        }
	}
}

