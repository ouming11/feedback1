﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;
using static LogEngine.ConsoleLoggerThread;

namespace LogEngine
{
    /// <summary>
    /// This class provides the most simplistic synchronous event logging to
    /// the console. Because of this, the performance impact is high and therefore
    /// not encouraged to be used.
    /// </summary>
    public class ConsoleLogger : Logger
    {
        #region Class Private Data
        private bool _verbose;
        private ConsoleColors? _consoleColors;

        static private Dictionary<string, ConsoleColor> colorMap = new()
        {
            { "Black", ConsoleColor.Black },
            { "DarkBlue", ConsoleColor.DarkBlue },
            { "DarkGreen", ConsoleColor.DarkGreen },
            { "DarkCyan", ConsoleColor.DarkCyan },
            { "DarkRed", ConsoleColor.DarkRed },
            { "DarkMagenta", ConsoleColor.DarkMagenta },
            { "DarkYellow", ConsoleColor.DarkYellow },
            { "DarkGray", ConsoleColor.DarkGray },
            { "Blue", ConsoleColor.Blue },
            { "Green", ConsoleColor.Green },
            { "Cyan", ConsoleColor.Cyan },
            { "Red", ConsoleColor.Red },
            { "Magenta", ConsoleColor.Magenta },
            { "Yellow", ConsoleColor.Yellow },
            { "White", ConsoleColor.White }
        };

        #endregion

        /// <summary>
        /// Constructor that initializes the Console logger
        /// </summary>
        /// <param name="verbose">True if Debug logging should be enabled</param>
        /// <param name="consoleColors">Optional colors to use for console output </param>
        public ConsoleLogger(bool verbose = false, ConsoleColors? consoleColors = null)
        {
            _verbose = verbose;

            if (consoleColors is null)
                consoleColors = GetDefaultColors();

            _consoleColors = consoleColors;
        }

        public override void DisposeResources()
        {
            // nothing to do for plain vanilla console output
        }

        ConsoleColors? GetDefaultColors()
        {
            ConsoleColors? consoleColors = null;

            try
            {
                var configBuilder = new ConfigurationBuilder().AddJsonFile("appsettings.json");
                IConfiguration configuration = configBuilder.Build();
                IConfigurationSection consoleSection = configuration.GetSection("ConsoleLoggerOptions");

                bool useColors = consoleSection.GetValue<bool>("UseColors");

                if (useColors == true)
                {
                    consoleColors = new();
                    consoleColors.Timestamp = GetColor(consoleSection.GetValue<string>("Timestamp"));
                    consoleColors.ErrorLevel = GetColor(consoleSection.GetValue<string>("ErrorLevel"));
                    consoleColors.WarningLevel = GetColor(consoleSection.GetValue<string>("WarningLevel"));
                    consoleColors.InfoLevel = GetColor(consoleSection.GetValue<string>("InfoLevel"));
                    consoleColors.TraceLevel = GetColor(consoleSection.GetValue<string>("TraceLevel"));
                    consoleColors.Message = GetColor(consoleSection.GetValue<string>("Message"));
                    consoleColors.Metadata = GetColor(consoleSection.GetValue<string>("Metadata"));
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return (consoleColors);
        }

        private ConsoleColor GetColor(string? colorText)
        {
#pragma warning disable CS8604
            return (colorMap[colorText]);
#pragma warning restore CS8604
        }

        /// <summary>
        /// Output a Trace message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public override void Trace(string msg)
        {
            if (_verbose == true)
            {
                LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Trace, msg, new MetaData());
            }
        }

        /// <summary>
        /// Output a Trace message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public override void Trace(string msg, MetaData meta)
        {
            if (_verbose == true)
            {
                LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Trace, msg, meta);
            }
        }

        /// <summary>
        /// Output a Error message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public override void Error(string msg)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Error, msg, new MetaData());
        }

        /// <summary>
        /// Output a Error message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Optional associated metadata</param>
        public override void Error(string msg, MetaData meta)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Error, msg, meta);
        }

        /// <summary>
        /// Output a Info message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public override void Info(string msg)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Info, msg, new MetaData());
        }

        /// <summary>
        /// Output a Info message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public override void Info(string msg, MetaData meta)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Info, msg, meta);
        }

        /// <summary>
        /// Output a Warning message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        public override void Warning(string msg)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Warning, msg, new MetaData());
        }

        /// <summary>
        /// Output a Warning message to the console
        /// </summary>
        /// <param name="msg">Message to show</param>
        /// <param name="meta">Associated metadata</param>
        public override void Warning(string msg, MetaData meta)
        {
            LogOneEvent(Helper.CallingProcessName(), DateTime.UtcNow, Level.Warning, msg, meta);
        }

        /// <summary>
        /// When greater control is needed at the expense of providing
        /// more parameters, this function can be used.
        /// </summary>
        /// <param name="source">Source of this event</param>
        /// <param name="dt">Timestamp of the event. Ideally in UTC</param>
        /// <param name="level">One of the Log Level enumerators</param>
        /// <param name="msg">Log message</param>
        public override void LogOneEvent(
            string source, DateTime dt, Level level, string msg
            )
        {
            LogOneEvent(source, dt, level, msg, new MetaData());
        }

        /// <summary>
        /// When greater control is needed at the expense of providing
        /// more parameters, this function can be used.
        /// </summary>
        /// <param name="source">Source of this event</param>
        /// <param name="dt">Timestamp of the event. Ideally in UTC</param>
        /// <param name="level">One of the Log Level enumerators</param>
        /// <param name="msg">Log message</param>
        /// <param name="meta">Associated metadata</param>
        public override void LogOneEvent(
            string source, DateTime dt, Level level, string msg,
            MetaData? meta
            )
        {
            List<KeyValuePair<string, ConsoleColor?>> consoleText = AppendBaseLogData(dt, level, source, msg);
            AppendMetadata(consoleText, meta);
            DisplayLog(consoleText);
        }

        /// <summary>
        /// Builds a list of strings coupled with their color codes to display
        /// </summary>
        /// <param name="level">String indicating the log level of message</param>
        /// <param name="msg">Message to shot</param>
        /// <exception cref="Exception">In case of an internal error</exception>
        private List<KeyValuePair<string, ConsoleColor?>> AppendBaseLogData(DateTime dt, Level level, string source, string msg)
        {
            List<KeyValuePair<string, ConsoleColor?>> consoleText = new();

            consoleText.Add(new KeyValuePair<string, ConsoleColor?>(
                string.Format("{0}, ", dt.ToString(Constant.DateFormat)),
                (_consoleColors != null) ? _consoleColors.Timestamp : null
                )
            );

            ConsoleColor? levelColor = null;

            switch (level)
            {
                case Level.Error:
                    levelColor = (_consoleColors != null) ? _consoleColors.ErrorLevel : null;
                    break;

                case Level.Warning:
                    levelColor = (_consoleColors != null) ? _consoleColors.WarningLevel : null;
                    break;

                case Level.Info:
                    levelColor = (_consoleColors != null) ? _consoleColors.InfoLevel : null;
                    break;

                case Level.Trace:
                    levelColor = (_consoleColors != null) ? _consoleColors.TraceLevel : null;
                    break;

                default:
                    throw new Exception(string.Format("Unrecognized Log Level: {0}", level));
            }

            // Conditionally adding a TAB character to ensure pretty formatting
            // 2023-02-03T05:59:10.891, Warning, MyApp, Warning without metdata
            // 2023-02-03T05:59:10.891, Info, MyApp, Info without metadata
            // 2023-02-03T05:59:10.891, Trace, MyApp, Trace without metadata

            consoleText.Add(new KeyValuePair<string, ConsoleColor?>(
                string.Format((level == Level.Warning) ? "{0}, " : "{0}\t, ", level.ToString()),
                levelColor
                )
            );

            consoleText.Add(new KeyValuePair<string, ConsoleColor?>(
                string.Format("{0}, ", source),
                (_consoleColors != null) ? _consoleColors.Message : null
                )
            );


            consoleText.Add(new KeyValuePair<string, ConsoleColor?>(
                string.Format("{0}", msg),
                (_consoleColors != null) ? _consoleColors.Message : null
                )
            );

            return (consoleText);
        }

        /// <summary>
        /// Appends metadata to the list of strings that makes up a log line
        /// on the console. This function is called recursively in case
        /// there are child metadata objects
        /// </summary>
        /// <param name="consoleText">List of strings coupled with their color codes to display</param>
        /// <param name="metaData">Optional associated metadata</param>
        private void AppendMetadata(
            List<KeyValuePair<string, ConsoleColor?>> consoleText,
            MetaData? metaData,
            string metaNamePrefix = ""
            )
        {
            if (metaData != null)
            {
                List<KeyValuePair<string, dynamic>> meta = metaData.GetMetadata();

                foreach (KeyValuePair<string, dynamic> kvp in meta)
                {
                    if (kvp.Value.GetType() == typeof(LogEngine.MetaData))
                    {
                        AppendMetadata(consoleText, kvp.Value, string.Format("{0}.", kvp.Key));
                    }
                    else
                    {
                        string str = string.Format(", {0}{1}={2}", metaNamePrefix, kvp.Key, kvp.Value.ToString());

                        ConsoleColor? c = (_consoleColors != null) ? _consoleColors.Metadata : null;

                        consoleText.Add(new KeyValuePair<string, ConsoleColor?>(str, c));
                    }
                }
            }
        }

        /// <summary>
        /// Takes the list of strings to display with their color codes and
        /// writes these to the display.
        /// </summary>
        /// <param name="consoleText">List of strings to display with their color codes</param>
        private void DisplayLog(List<KeyValuePair<string, ConsoleColor?>> consoleText)
        {
            foreach (KeyValuePair<string, ConsoleColor?> kvp in consoleText)
            {
                if (kvp.Value != null)
                {
                    Console.ForegroundColor = (ConsoleColor)kvp.Value;
                    Console.Write(kvp.Key);
                    Console.ResetColor();
                }
                else
                {
                    Console.Write(kvp.Key);
                }
            }

            Console.Write('\n');
        }
    }
}
