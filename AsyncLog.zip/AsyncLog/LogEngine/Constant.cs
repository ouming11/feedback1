﻿using System;

namespace LogEngine
{
	public static class Constant
	{
        public const string Time = "Time";
        public const string Level = "Level";
        public const string Message = "Message";
        public const string Source = "Source";
		public const string Trace = "Trace";
        public const string Info = "Info";
        public const string Warning = "Warning";
        public const string Error = "Error";
        public const string DateFormat = "yyyy-MM-ddTHH:mm:ss.fff";
    }
}

