﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

namespace LogEngine
{
	public class FileLogSource
	{
        private readonly string logSearchPattern = "{0}-*.log";
        private readonly string logFilePattern = "{0}-{1}.log";
        private readonly FileLogSettings fileLogSettings;
        private readonly string logSource;
        private readonly string sourceLogDir;
        private readonly long MaxLogFileSize;
        private readonly long OneKilobyte = 1024;
        private List<string> allLogFiles;
        private int logFileArrayIndex;

        public FileLogSource(string source)
		{
            allLogFiles = new();
            logSource = source;
            // Validates that the output directory exists
            fileLogSettings = new();
            MaxLogFileSize = fileLogSettings.FileSizeMbPerSource * (OneKilobyte * 1024);
            sourceLogDir = Path.Combine(fileLogSettings.RootLogDir, logSource);
            InitializeSource();
        }

        public void WriteLines(LinkedList<LogItem> logItems)
        {
            while (logItems.Count > 0)
            {
                LinkedList<LogItem> listToSaveInFile = new();
                long charsAvailable = CurrentLogFileCharsAvailable();

                if (charsAvailable < OneKilobyte)
                {
                    charsAvailable = RotateToNextLogFile();
                }

                foreach (LogItem item in logItems)
                {
                    int itemLength = item.Length(fileLogSettings.FileLogOutputCsv);

                    if (itemLength <= charsAvailable)
                    {
                        listToSaveInFile.AddLast(item);
                        charsAvailable -= itemLength;
                    }
                }

                if (listToSaveInFile.Count() > 0)
                {
                    // We have the maximum number of LogItem objects that
                    // we can save

                    using (StreamWriter sw = File.AppendText(GetCurrentLogFile()))
                    {
                        foreach (LogItem logItem in listToSaveInFile)
                        {
                            if (fileLogSettings.FileLogOutputCsv == true)
                                sw.WriteLine(logItem.ToCsvString());
                            else
                                sw.WriteLine(logItem.ToJsonString());
                        }

                        sw.Flush();
                    }

                    // We now remove from the logItems list all the objects
                    // that we saved.

                    foreach (LogItem logItem in listToSaveInFile)
                    {
                        logItems.Remove(logItem);
                    }
                }
            }
        }

        static public string[] GetAllLogSources()
        {
            FileLogSettings fileLogSettings = new();
            string [] allDirs = Directory.GetDirectories(fileLogSettings.RootLogDir);

            List<string> sourceNames = new();

            foreach(string oneDir in allDirs)
            {
                sourceNames.Add(Path.GetFileName(oneDir));
            }

            return (sourceNames.ToArray());
        }

        public FileBlock GetOldestEntries(int count)
        {
            FileBlock block = new();
            List<string> list = GetSortedListLogFiles();

            foreach(string oneFile in list)
            {
                int lineNum = 0;

                using (StreamReader sr = new StreamReader(oneFile))
                {
                    while (count > 0)
                    {
                        string? oneLine = sr.ReadLine();

                        if (oneLine is null)
                            break;

                        block.Add(oneFile, ++lineNum, oneLine);
                        count--;
                    }
                }

                if (count == 0)
                    break;
            }

            return (block);
        }

        #region Private

        private List<string> GetSortedListLogFiles()
        {
            List<string> sortedList;

            if (Directory.Exists(sourceLogDir) == false)
            {
                Directory.CreateDirectory(sourceLogDir);
            }

            string searchPattern = string.Format(logSearchPattern, logSource);

            sortedList = Directory.GetFiles(sourceLogDir, searchPattern).ToList();

            sortedList.Sort(
                delegate (string file1, string file2)
                {
                    DateTime dt1 = File.GetCreationTime(file1);
                    DateTime dt2 = File.GetCreationTime(file2);

                    return dt1.CompareTo(dt2);
                });

            return (sortedList);
        }

        /// <summary>
        /// 1 - Find all log files for the specified source
        /// 2 - Ensure the count of these files do not exceed specified max count
        /// 3 - Find the most recently created log file
        /// 4 - if Size of it is greater than max file size then
        ///     (a) find oldest log file
        ///     (b) delete it.
        ///     (c) create a new file to write to
        /// </summary>
        /// <param name="source">Log source</param>
        private void InitializeSource()
        {
            allLogFiles = GetSortedListLogFiles();

            // If there are more files than allowed per configuration cull the heard
            if (allLogFiles.Count > fileLogSettings.FileCountPerSource)
            {
                var deleteFiles = allLogFiles.Skip(fileLogSettings.FileCountPerSource);

                foreach (string oneDoomed in deleteFiles)
                {
                    File.Delete(oneDoomed);
                }

                allLogFiles = allLogFiles.Skip(0).Take(fileLogSettings.FileCountPerSource).ToList();

                // Open the oldest file for writing only and append if exists
                logFileArrayIndex = allLogFiles.Count - 1;
            }
            else
            {
                // Open the oldest file for writing only and append if exists
                logFileArrayIndex = (allLogFiles.Count > 0) ? allLogFiles.Count - 1 : 0;

                // Fill the remaining array slots with the file names that
                // should be used when current file is filled up.
                if (allLogFiles.Count < fileLogSettings.FileCountPerSource)
                {
                    int newFiles = fileLogSettings.FileCountPerSource - allLogFiles.Count;

                    for (int i = 0; i < newFiles; i++)
                    {
                        string newName = string.Format(logFilePattern, logSource, Guid.NewGuid());
                        allLogFiles.Add(Path.Combine(sourceLogDir, newName));
                    }
                }
            }

            // This is the file that should be appended to at the next write
            // allLogFiles[logFileArrayIndex]
        }

        private long CurrentLogFileCharsAvailable()
        {
            long charsAvailable = 0;

            if (File.Exists(GetCurrentLogFile()) == true)
            {
                long length = new System.IO.FileInfo(allLogFiles[logFileArrayIndex]).Length;

                if (length < MaxLogFileSize)
                    charsAvailable = MaxLogFileSize - length;
            }
            else
            {
                charsAvailable = MaxLogFileSize;
            }

            return (charsAvailable);
        }

        private long RotateToNextLogFile()
        {
            logFileArrayIndex++;

            if (logFileArrayIndex >= allLogFiles.Count)
            {
                logFileArrayIndex = 0;
            }

            File.Delete(allLogFiles[logFileArrayIndex]);

            return (MaxLogFileSize);
        }

        private string GetCurrentLogFile()
        {
            return (allLogFiles[logFileArrayIndex]);
        }

        #endregion
    }
}

