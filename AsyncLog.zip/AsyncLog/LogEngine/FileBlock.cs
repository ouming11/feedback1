﻿using System;
using System.Diagnostics;
using System.Reflection.PortableExecutable;

namespace LogEngine
{
	public class FileBlock
	{
		/// <summary>
		/// The dictionary key is the name of the file
		/// The dictionary value is a dictionary of line numbers and lines that
		/// the file contains.
		/// </summary>
		Dictionary<string, Dictionary<int, string>> dic;

        public FileBlock()
		{
            dic = new();
        }

		/// <summary>
		/// Adds a file information to this file block class
		/// </summary>
		/// <param name="filePath">full path and name to the file</param>
		/// <param name="lineNum">line number of the below line</param>
		/// <param name="line">line at the specified lineNum</param>
		public void Add(string filePath, int lineNum, string line)
		{
			if (dic.ContainsKey(filePath) == false)
			{
				dic.Add(filePath, new());
			}

            Dictionary<int, string> dicFile = dic[filePath];
            dicFile.Add(lineNum, line);
        }

		/// <summary>
		/// Returns the number of file informations in this block
		/// </summary>
		/// <returns>Number of file informations in this block</returns>
		public int Count()
		{
			int count = 0;

			foreach(KeyValuePair<string, Dictionary<int,string>> kvpDic in dic)
			{
				count += kvpDic.Value.Count;
			}

			return (count);
		}

        /// <summary>
        /// Get a specific file information at the specified index
        /// </summary>
        /// <param name="idx">Index of interest</param>
        /// <param name="fullPath">full path and name to the file</param>
		/// <param name="lineNum">line number of the below line</param>
		/// <param name="line">line at the specified lineNum</param>
        /// <returns>Boolean success or failed</returns>
        public bool GetAt(int idx, out string fullPath, out int lineNum, out string line)
		{
			bool success = false;
			fullPath = string.Empty;
			lineNum = -1;
			line = string.Empty;

            foreach (KeyValuePair<string, Dictionary<int, string>> kvpDic in dic)
            {
                if (idx < kvpDic.Value.Count)
				{
                    KeyValuePair<int, string> kvp = kvpDic.Value.ToArray()[idx];

                    fullPath = kvpDic.Key;
                    lineNum = kvp.Key;
					line = kvp.Value;
					success = true;
					break;
                }
				else
				{
					idx -= kvpDic.Value.Count;
                }
            }

			return (success);
        }

		public void DeleteAll()
		{
            foreach (KeyValuePair<string, Dictionary<int, string>> kvpDic in dic)
            {
				string strOutFile = string.Format("{0}.tmp", kvpDic.Key);

				using (StreamWriter sw = new StreamWriter(strOutFile))
				{
					using (StreamReader sr = new StreamReader(kvpDic.Key))
					{
						Dictionary<int, string> kvp = kvpDic.Value;

                        string? line;
						int lineNum = 0;

                        while ((line = sr.ReadLine()) != null)
                        {
                            lineNum++;

							if (kvp.ContainsKey(lineNum) == true)
							{
#if DEBUG
								string strDoomed = kvp[lineNum];
								Debug.Assert(string.Compare(line, strDoomed) == 0);
#endif
								continue;
							}

                            sw.WriteLine(line);
                        }
                    }
				}

				File.Delete(kvpDic.Key);
				File.Move(strOutFile, kvpDic.Key, true);
            }
        }
	}
}

