﻿using System;
using System.Diagnostics;
using System.Drawing;
using LogEngine;

namespace AsyncLogTest
{
    class Program
    {
        private enum MenuSelection
        {
            NotInitialized,
            Synchronous,
            Asynchronous,
            Threading,
            File,
            HttpOneLog,
            HttpManyLogs,
            Exit
        };

        static void Main(string[] args)
        {
            try
            {
                ConsoleColors colors = new();

                colors.Timestamp = ConsoleColor.DarkYellow;
                colors.ErrorLevel = ConsoleColor.Red;
                colors.WarningLevel = ConsoleColor.Magenta;
                colors.InfoLevel = ConsoleColor.DarkGreen;
                colors.TraceLevel = ConsoleColor.DarkGray;
                colors.Message = ConsoleColor.DarkBlue;
                colors.Metadata = ConsoleColor.DarkGreen;

                int NumIterations;
                long ElapsedMilliseconds = -1;
                ILogger? logger = null;

                switch (DisplayMenu(out NumIterations))
                {
                    case MenuSelection.Synchronous:
                        logger = SynchConsoleWriter(NumIterations, out ElapsedMilliseconds, colors);
                        break;

                    case MenuSelection.Asynchronous:
                        logger = AsynchConsoleWriter(NumIterations, out ElapsedMilliseconds, colors);
                        break;

                    case MenuSelection.Threading:
                        logger = ThreadConsoleWriter(NumIterations, out ElapsedMilliseconds, colors);
                        break;

                    case MenuSelection.File:
                        logger = FileLogWriter(NumIterations, out ElapsedMilliseconds);
                        break;

                    case MenuSelection.HttpOneLog:
                        logger = HttpLogWriterSyncOne(out ElapsedMilliseconds);
                        break;

                    case MenuSelection.HttpManyLogs:
                        logger = HttpLogWriterSync(NumIterations, out ElapsedMilliseconds);
                        break;

                    case MenuSelection.Exit:
                        Console.WriteLine("Terminating..");
                        break;
                }

                if (ElapsedMilliseconds != -1)
                {
                    Console.ReadKey();
                    Console.WriteLine("Elapsed time to log {0} events is {1} ms", NumIterations * 8, ElapsedMilliseconds);
                }

                if (logger is not null)
                    logger.DisposeResources();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static MenuSelection DisplayMenu(out int NumIterations)
        {
            NumIterations = 1;
            MenuSelection selection = MenuSelection.NotInitialized;

            while (selection == MenuSelection.NotInitialized)
            {
                Console.WriteLine("\nThere will be many log entries written and" +
                    " depending on what algorithm you select, writing will be" +
                    " completed much sooner than display. Once output stops then" +
                    "press a key to display elapsed time.\n");

                Console.WriteLine("\nSelect log algorithm to test\n");
                Console.WriteLine("1.- Console Synchronous");
                Console.WriteLine("2.- Console Asynchronous");
                Console.WriteLine("3.- Console Threading");
                Console.WriteLine("4.- File Output");
                Console.WriteLine("5.- HTTP POST JSON - one log");
                Console.WriteLine("6.- HTTP POST JSON - many logs");
                Console.WriteLine("0.- Exit");

                ConsoleKeyInfo ki = Console.ReadKey();
                Console.WriteLine();

                switch (ki.KeyChar)
                {
                    case '0':
                        selection = MenuSelection.Exit;
                        break;

                    case '1':
                        selection = MenuSelection.Synchronous;
                        break;

                    case '2':
                        selection = MenuSelection.Asynchronous;
                        break;

                    case '3':
                        selection = MenuSelection.Threading;
                        break;

                    case '4':
                        selection = MenuSelection.File;
                        break;

                    case '5':
                        selection = MenuSelection.HttpOneLog;
                        break;

                    case '6':
                        selection = MenuSelection.HttpManyLogs;
                        break;
                    default:
                        throw new Exception("Unrecognized character typed");
                }

                Console.Write("\nHow many iterations? ['Return' for 1]: ");
                string? str = Console.ReadLine();

                if (int.TryParse(str, out NumIterations) == false)
                {
                    NumIterations = 1;
                }
            }

            return (selection);
        }

        private static ILogger SynchConsoleWriter(int NumIterations, out long ElapsedMilliseconds, ConsoleColors colors)
        {
            ILogger logger = new ConsoleLogger(true, null);
            ElapsedMilliseconds = LogWriter(NumIterations, logger);
            return (logger);
        }

        private static ILogger AsynchConsoleWriter(int NumIterations, out long ElapsedMilliseconds, ConsoleColors colors)
        {
            ILogger logger = new ConsoleLoggerAsync(true, colors);
            ElapsedMilliseconds = LogWriter(NumIterations, logger);
            return (logger);
        }

        private static ILogger ThreadConsoleWriter(int NumIterations, out long ElapsedMilliseconds, ConsoleColors colors)
        {
            ILogger logger = new ConsoleLoggerThread(true, colors);
            ElapsedMilliseconds = LogWriter(NumIterations, logger);
            return (logger);
        }

        private static ILogger FileLogWriter(int NumIterations, out long ElapsedMilliseconds)
        {
            ILogger logger = new FileLogger();
            ElapsedMilliseconds = LogWriter(NumIterations, logger);
            return (logger);
        }

        private static ILogger HttpLogWriterSyncOne(out long ElapsedMilliseconds)
        {
            ElapsedMilliseconds = 0;
            MetaData meta = CreateMetadata();
            ILogger logger = new HttpClientLoggerSync();
            logger.Info("Hello World", meta);

            return (logger);
        }

        private static ILogger HttpLogWriterSync(int NumIterations, out long ElapsedMilliseconds)
        {
            ILogger logger = new HttpClientLoggerSync();
            ElapsedMilliseconds = LogWriter(NumIterations, logger);
            return (logger);
        }

        private static long LogWriter(int NumIterations, ILogger logger)
        {
            Stopwatch sw = new();

            MetaData meta = CreateMetadata();

            sw.Start();
            for (int i = 0; i < NumIterations; i++)
            {
                WriteOneLogOfEach(i, logger, meta);
            }
            sw.Stop();

            return (sw.ElapsedMilliseconds);
        }

        private static MetaData CreateMetadata()
        {
            MetaData fruits = new();
            fruits.Add("berry", "strawberry");
            fruits.Add("citrus", "orange");
            fruits.Add("random", DateTime.Now.Ticks.ToString());

            MetaData animals = fruits.CreateChild("animals");
            animals.Add("dog", "Labrador");
            animals.Add("bird", "Parrot");
            animals.Add("count", 2);

            return (fruits);
        }

        private static void WriteOneLogOfEach(int index, ILogger logger, MetaData meta)
        {
            logger.Error(string.Format("{0} Error without metadata", index));
            logger.Warning(string.Format("{0} Warning without metdata", index));
            logger.Info(string.Format("{0} Info without metadata", index));
            logger.Trace(string.Format("{0} Trace without metadata", index));

            logger.Error(string.Format("{0} Error with metadata", index), meta);
            logger.Warning(string.Format("{0} Warning with metdata", index), meta);
            logger.Info(string.Format("{0} Info with metadata", index), meta);
            logger.Trace(string.Format("{0} Trace with metadata", index), meta);
        }
    }
}
